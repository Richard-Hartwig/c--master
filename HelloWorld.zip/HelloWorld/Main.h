#pragma once
#include <string.h>;
#include <math.h>;
#include <iostream>;
#include <array>;


using namespace std;
