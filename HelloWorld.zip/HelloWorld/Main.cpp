#include "Main.h";
#include "ShapeClass.h";

int main(){

	//Shape *shape;
	Rectangle rectangle;
	Circle circle;
	Sector sector;
	Triangle triangle;
	Trapezoid trapazoid;
	Square square;
	double radius, angle;
	int length, width, base, height, ShapeSide1, ShapeSide2, ShapeSide3;

	cout << "Hello\n I can find the area of a shape. What would you like to find? \n Press '1' for Rectangle\n Press '2' for Circle\nPress '3' for sector\nPress '4' for triangle\nPress '5' for Trapazoid\nPress '6' for square\n";
	
	int ch = 0;
	cin >> ch;
	
	switch (ch) 
	{

	case 1: // Rectangle

		cout << "Enter the width for the Rectangle.";
		cin >> width;
		cout << " Enter the length for the Rectangle.";
		cin >> length;
		
		cout << "The area of the Rectangle is "<< rectangle.GetAreaRect(width, length) << endl;
		cout << "The perimeter of the Rectangle is " << rectangle.GetPerimeter(width, length) << endl;
	break;


	case 2: // circle
		
		cout << "Enter the radius for the circle.\n";		
		cin >> radius;

		cout << "The perimeter of the circle " << circle.GetPerimeter(radius) << endl;
		cout << "The area of the circle is " << circle.GetArea(radius) << endl;

	break;

	case 3:// sector

		cout << "Enter the radius for the sector.\n";
		cin >> radius;
		cout << "Enter the angle of the sector.";
		cin >> angle;

		cout << "\nThe area of the sector is " << sector.GetArea(radius)<<endl;
		cout << "The perimeter of the sector is " << sector.GetPerimeter(radius, angle) << endl;
	break;

	case 4:// triangle
		cout << "Enter the base for the triangle.";
		cin >> base;
		cout << "Enter the height for the triangle.";
		cin >> height;
		cout << "Enter side 2\n";
		cin >> ShapeSide1;
		cout << "Enter side 3\n";
		cin >> ShapeSide2;

		cout << "The area of the triangle is " << triangle.GetArea(base, height) << endl;
		cout << "The perimeter of the triangle is " << triangle.GetPerimeter(ShapeSide1, ShapeSide2, base) << endl;
	break;

	case 5: // Trapezoid
		cout << "Enter the base for the trapazoid";
		cin >> base;
		cout << "Enter the first side for the trapazoid";
		cin >> ShapeSide1;
		cout << "Enter the height for the trapazoid";
		cin >> height;
		cout << "Enter the second side for the trapazoid";
		cin >> ShapeSide2;
		cout << "Enter the third side for the trapazoid";
		cin >> ShapeSide3;

		cout << "The area of the trapazoid is " << trapazoid.getArea(base, ShapeSide1, height) << endl;
		cout << "The perimeter of the trapazoid is " << trapazoid.getPerimeter(base, ShapeSide1, ShapeSide2, ShapeSide3) << endl;
		break;
	case 6:
		cout << "Enter the length of the square";
		cin >> length;
		cout << "The area of the square is " << square.GetArea(length) <<endl;
		cout << "The perimeter of the square is " << square.GetPerimeter(length) << endl;



//	default:
	//	cout << "This is the end";
	}

	
	system("pause");
	return 0;

	
}