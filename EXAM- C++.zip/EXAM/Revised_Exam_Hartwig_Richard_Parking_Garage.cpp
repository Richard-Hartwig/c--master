#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define MINCHARGE 2.00
#define MAXCHARGE 10.00
#define CHARGE .5
#define STAR "**********"
#define LINE "___________"

double Charges(double hours); 
int main()
{
	double hour; 	
	double currentCharge; 
	double finalCharges = 0.0; 
	double finalHours = 0.0; 
	int car;
	int first = 1; 
	printf("	Enter the hours parked for 3 cars (between 0 - 24 hours):\n\nYour Input here		");
	printf("Correct Input, moves here\n%s*****		%s%s*****\n\n\n",STAR,STAR,STAR);
	
	for (car = 1; car <= 3; car++)
	{
		if (first) {
			printf("%20s%15s%15s\n", "Car", "Hours", "Charge");
			printf("		 %s%s%s\n", LINE, LINE, LINE);
			first = 0;
		}
		scanf_s("%lf", &hour);
		if (hour <= 24.0 && hour >= 0){ finalHours = finalHours + hour; }
		else if (hour > 24.0){ --car; }
		else if (hour < 0) { --car; }		
		if (hour <= 24.0 && hour >= 0)
		{ finalCharges += (currentCharge = Charges(hour));
		printf("	     --->  %d%15.1f%15.2f\n", car, hour, currentCharge);
		}	}
	
	printf("		 %s%s%s\n", LINE, LINE, LINE); 
	printf("%20s%15.1f%15.2f\n\n", "TOTAL", finalHours, finalCharges);
	system("pause");
	return 0; 
} 
double Charges(double hours)
{
	double charge; 
	if (hours < 3.0 && hours <= 24.00) {charge = MINCHARGE;	} 	
	else if (hours < 19.0 && hours <= 24.00) {	charge = 2.0 + .5 * ceil(hours - 3.0);	}
	else if (hours > 19.0 && hours <= 24.00){ charge = MAXCHARGE; }
	return charge; 
} 