﻿#include <stdio.h>
#include<stdlib.h>
#define COMMISSION 0.09
#define WEEKLY 200

int main(void)
{
	int storage[11] = { 0 }; 
	int sales; 
	double total; 

	printf("Enter employee gross sales ( -1 to end ): ");
	scanf_s("%d", &sales);

	while (sales != -1) {		
		total = WEEKLY + sales * COMMISSION;
		printf("Employee Salary is $%.2f\n", total);

		if (total >= 200 && total < 1000) {
			++storage[(int)total / 100];	} 
		else if (total >= 1000) {	++storage[10];	} 
				
		printf("\nEnter employee gross sales ( -1 to end ): ");
		scanf_s("%d", &sales);
	} /*end while*/
		
	printf("\nEmployees in the range:\n");
	printf("$200-$299 : %d\n", storage[2]);
	printf("$300-$399 : %d\n", storage[3]);
	printf("$400-$499 : %d\n", storage[4]);
	printf("$500-$599 : %d\n", storage[5]);
	printf("$600-$699 : %d\n", storage[6]);
	printf("$700-$799 : %d\n", storage[7]);
	printf("$800-$899 : %d\n", storage[8]);
	printf("$900-$999 : %d\n", storage[9]);
	printf("Over $1000: %d\n", storage[10]);

	system("pause");

	return 0;
}